var CreationTableauLangages = function () {

}

var CreationTableauNombres = function () {

}

var RemplacementElement = function (langages) {

}

var AjoutElementLangages = function (langages) {

}

var AjoutElementNombres = function (nombres) {

}

var SuppressionPremierElement = function (langages) {

}

var SuppressionDernierElement = function (langages) {

}

var ConversionChaineTableau = function (reseaux_sociaux_chaine) {

}

var ConversionTableauChaine = function (langages) {

}

var TriTableau = function (reseaux_sociaux) {

}

var InversionTableau = function (reseaux_sociaux){

}
