/**
 * Exercice sur les chaines de caractères.
 * Trouvez la façon de faire la plus optimal.
 * Il peut y avoir plusieur façon de faire.
 */
var tailleString = function (texte) {

}
var remplaceECar = function (texte) {

}
var concatString = function (texte1, texte2) {

}
var afficherCar5 = function (texte) {

}
var afficher9Car = function (texte) {

}
var majusculeString = function (texte) {

}
var minusculeString = function (texte) {

}
var SupprEspaceString = function (texte) {

}
var IsString = function (texte) {

}

var AfficherExtensionString = function (texte) {

}
var NombreEspaceString = function (texte) {

}
var InverseString = function (texte) {

}

/**
 * Exercices sur les nombres et les caluls mathématiques
 */
var calculPuissance = function (x, y) {

}
var valeurAbsolue = function (nombre) {

}
var valeurAbsolueArray = function (array) {

}
var sufaceCercle = function (rayon) {

}
var hypothenuse = function (ab, ac) {

}
var calculIMC = function (poids, taille) {

}
